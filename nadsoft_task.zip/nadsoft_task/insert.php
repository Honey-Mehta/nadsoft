<?php
//insert.php  
$connect = mysqli_connect("localhost", "root", "", "nadsoft");
if(!empty($_POST))
{
 $output = '';
 $name = mysqli_real_escape_string($connect, $_POST["name"]);  
    $parent_id = mysqli_real_escape_string($connect, $_POST["parentid"]);  
    
    $query = "
    INSERT INTO members(name, parentid)  
     VALUES('$name', '$parent_id')
    ";
    if(mysqli_query($connect, $query))
    {
     $output .= '<label class="text-success">Data Inserted</label>';
     $select_query = "SELECT * FROM members ORDER BY id DESC";
     $result = mysqli_query($connect, $select_query);
     $output .= '
      <div class="table table-bordered">  
                  

     ';
     while($row = mysqli_fetch_assoc($result))
     {
         $parent_query="SELECT * FROM parent where id='".$row['parentid']."'";
          $parent=mysqli_fetch_assoc(mysqli_query($connect,$parent_query));
      $output .= '
       <ul> '.$parent["parent_name"].'
                         <li>' . $row["name"] . '</li>  
                         
                    </ul>
      ';
     }
     $output .= '</table>';
    }
    echo $output;
}
?>

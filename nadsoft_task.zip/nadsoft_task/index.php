<?php  
//index.php
$connect = mysqli_connect("localhost", "root", "", "nadsoft");
$query = "SELECT * FROM members ORDER BY id DESC";
$result = mysqli_query($connect, $query);
 ?>  
<!DOCTYPE html>  
<html>  
 <head>  
  <title>Webslesson Tutorial | Bootstrap Modal with Dynamic MySQL Data using Ajax & PHP</title>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
 </head>  
 <body>  
  <br /><br />  
  <div class="container" style="width:700px;">  
  
   <br />  
   <div class="table-responsive">
    
    <br />
    <div id="employee_table">
     
     
      <?php
      while($row = mysqli_fetch_assoc($result))
      {
      ?>
      <ul>
       <li><?php echo $row["name"]; ?></li>
      
      </ul>
      <?php
      }
      ?>
     
    </div>
   </div>  
 <div align="Left">
     <button type="button" name="age" id="age" data-toggle="modal" data-target="#add_data_Modal" class="btn btn-warning">Add</button>
    </div>
  </div>

 </body>  
</html>  

<div id="add_data_Modal" class="modal fade">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
   
   </div>
   <div class="modal-body">
    <form method="post" id="insert_form">
     <h3>Add Member</h3>
     
     <label>Parent</label>
     <select name="parentid" id="parentid" class="form-control">
      <option value="">--Select Parent--</option>  
  <?php
    $query2 ="SELECT * from parent";
    $result2 = mysqli_query($connect, $query2);
        while($optionData=mysqli_fetch_assoc($result2)){
        $option =$optionData['parent_name'];
        $id =$optionData['id'];
  
  ?>
      <option value="<?php echo $id; ?>"><?php echo $option; ?></option>  
    
      <?php
    }
    ?>
     </select>
     <br />  
     
       <label>Name</label>
     <input type="text" name="name" id="name" class="form-control" />
     <br />
     <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-success" />

    </form>
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>

<div id="dataModal" class="modal fade">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title">Employee Details</h4>
   </div>
   <div class="modal-body" id="employee_detail">
    
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>

<script>  
$(document).ready(function(){
 $('#insert_form').on("submit", function(event){  
  event.preventDefault();  
  if($('#name').val() == "")  
  {  
   alert("Name is required");  
  }  
  else if($('#parentid').val() == '')  
  {  
   alert("Parent is required");  
  }  
 
   
  else  
  {  
   $.ajax({  
    url:"insert.php",  
    method:"POST",  
    data:$('#insert_form').serialize(),  
    beforeSend:function(){  
     $('#insert').val("Inserting");  
    },  
    success:function(data){  
     $('#insert_form')[0].reset();  
     $('#add_data_Modal').modal('hide');  
     $('#employee_table').html(data);  
    }  
   });  
  }  
 });




 $(document).on('click', '.view_data', function(){
  //$('#dataModal').modal();
  var employee_id = $(this).attr("id");
  $.ajax({
   url:"select.php",
   method:"POST",
   data:{employee_id:employee_id},
   success:function(data){
    $('#employee_detail').html(data);
    $('#dataModal').modal('show');
   }
  });
 });
});  
 </script>